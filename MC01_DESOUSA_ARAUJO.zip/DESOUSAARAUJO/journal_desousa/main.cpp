#include <iostream>
#include <string.h>
#include <sstream>
#include <stdio.h>
#include "SNAfficheur.h"
#include "SNLigne.h"


using namespace std;

int main()
{
    char phrase[250];
    float val1,val2,res;
    char operateur;
    sprintf(phrase,"%.3f %c %.3f = %.3f", val1, operateur, val2, res);
    cout<<"Saisir votre calcul: ";
    cin>>val1>>operateur>>val2;
      if (operateur == '+')
      {
          res=val1+val2;
      }
      if (operateur == '-')
      {
          res=val1-val2;
      }
      sprintf(phrase,"%.3f %c %.3f = %.3f", val1, operateur, val2, res);
      cout<<phrase;
    SNAfficheur aff;
    aff.ModifierAdresseIPDuServeurUDP("172.20.21.157");
    aff.ModifierPortDuServeurUDP(4321);
    SNLigne Lg;
    Lg.ModifierMessage(phrase);
    aff.EnvoyerLigneEnUDP(Lg);
	return 0;
}
