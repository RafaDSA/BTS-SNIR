
#include <iostream>
#include "SNAfficheur.h"
#include <stdio.h>
#include "SNLigne.h"

using namespace std;


int main(int argc, char * argv[])
{
        SNAfficheur aff;
        aff.ModifierAdresseIPDuServeurUDP("172.20.182.50");
        aff.ModifierPortDuServeurUDP(4321);
        SNLigne Lg;
        Lg.ModifierMessage(phase);
        aff.EnvoyerLigneEnUDP(Lg);      
	return 0;
}
