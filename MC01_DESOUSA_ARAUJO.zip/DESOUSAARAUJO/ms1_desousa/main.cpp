#include <iostream>
#include <cmath>
#include <string.h>
#include <sstream>
#include <stdio.h>


using namespace std;

int SaisirBinaire()
{
    char bin[100];
    int nombre = 0;
    cin>>bin;
    for (int i=0;i<strlen(bin);i++)
        {
            nombre = nombre*2+(bin[i]-'0');
    }
    return nombre;
}
string EntierChaineEnBinaire(int nombre)
{
    ostringstream oss;
    bool copie = false;
    for(int i=31;i>=0;i--)
        {
            if(((nombre>>i)&1)==1)
            {
                copie = true;
                }
                if (copie==true)
                    {
                        oss<<((nombre>>i)&1);
                }
                }
                return oss.str();
                }

int main()
{
    char phrase[200];
    int choix;
    cout<<"calcul (1), Trigo (2), Conversion (3) ? : ";
    cin>>choix;
    if (choix == 1)
    {
      cout<<"Vous avez choisis le calcul"<<endl;
      float val1,val2,res;
      char operateur;
      sprintf(phrase,"%.3f %c %.3f = %.3f", val1, operateur, val2, res);
      cout<<"Saisir votre calcul: ";
      cin>>val1>>operateur>>val2;
      if (operateur == '+')
      {
          res=val1+val2;
      }
      if (operateur == '-')
      {
          res=val1-val2;
      }
      sprintf(phrase,"%.3f %c %.3f = %.3f", val1, operateur, val2, res);
      cout<<phrase;
    }
    if (choix == 2)
    {
        cout<<"Vous avez choisis la Trigo"<<endl;
        char fTrigo[10];
        float val1,res,xDegrees = 25,angle;
        cout<<"Saisir la fonction val1 : ";
        cin>>fTrigo>>val1;
        cout<<"DEGRES (1), RADIAN(2) ? : ";
        cin>>angle;
        if (angle == 2)
        {
            if (strcmp(fTrigo, "cos") == 0)
        {
            res = cos(val1);
            cout<<"cos(x) = "<<res<<endl;
        }
        if (strcmp(fTrigo, "sin") == 0)
        {
            res = sin(val1);
            cout<<"sin(x) = "<<res<<endl;
        }
        if (strcmp(fTrigo, "tan") == 0)
        {
            res = tan(val1);
            cout<<"tan(x) = "<<res<<endl;
        }
        }
        if (angle == 1)
        {
            if (strcmp(fTrigo, "cos") == 0)
        {
            res = (cos(val1))*(180/M_PI);
            cout<<"cos(x) = "<<res<<endl;
        }
        if (strcmp(fTrigo, "sin") == 0)
        {
            res = (sin(val1))*(180/M_PI);
            cout<<"sin(x) = "<<res<<endl;
        }
        if (strcmp(fTrigo, "tan") == 0)
        {
            res = (tan(val1))*(180/M_PI);
            cout<<"tan(x) = "<<res<<endl;
        }
        }
    }
    if (choix ==3)
    {
        cout<<"Vous avez choisis la conversion"<<endl;
        int nb,base;
        cout<<"Choix de la base de saisie : Decimal (1), Hexa (2), Binaire (3) ? : ";
        cin>>base;
        cout<<"Saisir un nombre entier : ";
        if (base == 1)
        {
            cin>>nb;
            cout<<"Choix de la base d'affichage : Decimal (1), Hexa (2), Binaire (3) ? : ";
            cin>>base;
            if (base == 1)
            {
                cout<<nb;
            }
            if (base == 2)
            {
                cout<<hex<<nb;
            }
            if (base == 3)
            {
                cout<<EntierChaineEnBinaire(nb);
            }
        }
        if (base == 2)
        {
            cin>>hex>>nb;
            cout<<"Choix de la base d'affichage : Decimal (1), Hexa (2), Binaire (3) ? : ";
            cin>>base;
            if (base == 1)
            {
                cout<<dec<<nb;
            }
            if (base == 2)
            {
                cout<<nb;
            }
            if (base == 3)
            {
                cout<<EntierChaineEnBinaire(nb);
            }
        }
        if (base == 3)
        {
            nb = SaisirBinaire();
            cout<<"Choix de la base d'affichage : Decimal (1), Hexa (2), Binaire (3) ? : ";
            cin>>base;
            if (base == 1)
            {
                cout<<dec<<nb;
            }
            if (base == 2)
            {
                cout<<hex<<nb;
            }
            if (base == 3)
            {
                cout<<EntierChaineEnBinaire(nb);
            }
        }

    }
    return 0;
}
