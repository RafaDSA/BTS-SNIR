//---------------------------------------------------------------------------

#ifndef DMXTCPH
#define DMXTCPH
//---------------------------------------------------------------------------
#include "SNClientTCP.h"
class DMXTCP
{   private:
	SNClientTCP monClient;
	unsigned char trame[512];
	public:
	DMXTCP();
	void ModifierCanal(unsigned short canal,unsigned char valeur);
	void Envoyer(char IP[50],unsigned short port);
	void FullOn();
	void FullOff();
	void Demonstration();
};

#endif
