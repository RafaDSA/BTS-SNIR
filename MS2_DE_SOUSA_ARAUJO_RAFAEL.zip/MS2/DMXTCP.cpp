//---------------------------------------------------------------------------

#pragma hdrstop

#include "DMXTCP.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
DMXTCP::DMXTCP()
{	for(int i=0;i<512;i++) trame[i]=0;
}
void DMXTCP::ModifierCanal(unsigned short canal,unsigned char valeur)
{   trame[canal-1]=valeur;
}
void DMXTCP::Envoyer(char IP[50],unsigned short port)
{	monClient.SeConnecterAUnServeur(IP,port);
	monClient.Envoyer(trame,512);
}
void DMXTCP::FullOn()
{   for(int i=0;i<512;i++) trame[i]=255;
}
void DMXTCP::FullOff()
{	 for(int i=0;i<512;i++) trame[i]=0;
}
void DMXTCP::Demonstration()
{   unsigned char val[512];
	srand(time(0));
	for(int i=0;i<512;i++)
	{	trame[i]=rand();
	}
}

