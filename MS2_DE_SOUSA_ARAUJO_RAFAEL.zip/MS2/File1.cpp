#pragma hdrstop
#pragma argsused

#ifdef _WIN32
#include <tchar.h>
#else
  typedef char _TCHAR;
  #define _tmain main
#endif

#include <stdio.h>
#include "SNClientTCP.h"
#include "DMXTCP.h"
#include <iostream>

 int _tmain(int argc, _TCHAR* argv[])
{   int pan, lumiere, tilt, couleur, forme;
	DMXTCP monDMXTCP;
	bool ON=true;
	while(true){
	/* cin>>ON;
	if(ON) monDMXTCP.FullOn();
	else monDMXTCP.FullOff();
	monDMXTCP.Envoyer("172.20.21.37",4123);   */
	cout<<"Combien de degres de rotation ? : ";
	cin>>pan;
	cout<<"Combien en horizontal ? : ";
	cin>>tilt;
	cout<<"lumiere ? : ";
	cin>>lumiere;
	cout<<"Quelle couleur ? : ";
	cin>>couleur;
	cout<<"Quelle forme ? : ";
	cin>>forme;
	monDMXTCP.ModifierCanal(1,pan);
	monDMXTCP.ModifierCanal(3,lumiere);
	monDMXTCP.ModifierCanal(2,tilt);
	monDMXTCP.ModifierCanal(5,couleur);
	monDMXTCP.ModifierCanal(6,forme);
	monDMXTCP.Envoyer("172.20.21.37",4123);
	}
		return 0;
}

/* {   unsigned char trame[512];
	int pan,couleur,forme,tilt;
	SNClientTCP monClientDMX;
	while(true){
	cout<<"Combien de degres de rotation ? : ";
	cin >> pan;
	cout<<"Combien en horizontal ? : ";
	cin >> tilt;
	cout<<"Quelle couleur ? : ";
	cin >> couleur;
	cout<<"Quelle forme ? : ";
	cin >> forme;
	trame[0]=pan;
	trame[1]=tilt;
	trame[4]=couleur;
	trame[5]=forme;
	monClientDMX.SeConnecterAUnServeur("172.20.21.37",4123);
	monClientDMX.Envoyer(trame,512);

	}

	return 0;
}     */
