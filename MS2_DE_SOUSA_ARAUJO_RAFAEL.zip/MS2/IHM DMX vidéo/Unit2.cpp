//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <stdlib.h>
#include "Unit2.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm2::Button1Click(TObject *Sender)
{      monDMXTCP.Envoyer("172.20.21.37",4123);

}
//---------------------------------------------------------------------------
void __fastcall TForm2::ScrollBar1Change(TObject *Sender)
{     monDMXTCP.ModifierCanal(1,255-ScrollBar1->Position);
	  Label5->Caption=255-ScrollBar1->Position;
}
//---------------------------------------------------------------------------
void __fastcall TForm2::ScrollBar2Change(TObject *Sender)
{     monDMXTCP.ModifierCanal(2,255-ScrollBar2->Position);
Label6->Caption=255-ScrollBar2->Position;

}
//---------------------------------------------------------------------------
void __fastcall TForm2::ScrollBar3Change(TObject *Sender)
{      monDMXTCP.ModifierCanal(3,255-ScrollBar3->Position);
Label7->Caption=255-ScrollBar3->Position;

}
//---------------------------------------------------------------------------
void __fastcall TForm2::ScrollBar5Change(TObject *Sender)
{     monDMXTCP.ModifierCanal(5,255-ScrollBar5->Position);
Label9->Caption=255-ScrollBar5->Position;

}
//---------------------------------------------------------------------------
void __fastcall TForm2::ScrollBar6Change(TObject *Sender)
{     monDMXTCP.ModifierCanal(6,255-ScrollBar6->Position);
Label10->Caption=255-ScrollBar6->Position;

}
//---------------------------------------------------------------------------
void __fastcall TForm2::FullOnClick(TObject *Sender)
{      ScrollBar1->Position = 0;
	   ScrollBar2->Position = 0;
	   ScrollBar3->Position = 0;
	   ScrollBar4->Position = 0;
	   ScrollBar5->Position = 0;
	   ScrollBar6->Position = 0;
	   ScrollBar7->Position = 0;
	   ScrollBar8->Position = 0;
	   ScrollBar9->Position = 0;
	   ScrollBar10->Position = 0;
}
//---------------------------------------------------------------------------
void __fastcall TForm2::FullOffClick(TObject *Sender)
{      ScrollBar1->Position = 255;
	   ScrollBar2->Position = 255;
	   ScrollBar3->Position = 255;
	   ScrollBar4->Position = 255;
	   ScrollBar5->Position = 255;
	   ScrollBar6->Position = 255;
	   ScrollBar7->Position = 255;
	   ScrollBar8->Position = 255;
	   ScrollBar9->Position = 255;
	   ScrollBar10->Position = 255;

}
//---------------------------------------------------------------------------
void __fastcall TForm2::Timer1Timer(TObject *Sender)
{       monDMXTCP.Demonstration();
monDMXTCP.Envoyer((AnsiString(Edit1->Text).c_str()),4123);

}
//---------------------------------------------------------------------------

void __fastcall TForm2::Button2Click(TObject *Sender)
{      if(Button2->Caption=="D�mo"){
			Timer1->Enabled=True;
			Button2->Caption="Stop";}
	   else if(Button2->Caption=="Stop"){
			Timer1->Enabled=False;
			Button2->Caption="D�mo";}

}
//---------------------------------------------------------------------------

void __fastcall TForm2::SpeedButton1Click(TObject *Sender)
{     ScrollBar6->Position = 122;

}
//---------------------------------------------------------------------------

void __fastcall TForm2::SpeedButton2Click(TObject *Sender)
{     ScrollBar6->Position = 57;

}
//---------------------------------------------------------------------------

void __fastcall TForm2::SpeedButton4Click(TObject *Sender)
{
ScrollBar6->Position = 112;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::SpeedButton5Click(TObject *Sender)
{
ScrollBar6->Position = 42;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::SpeedButton7Click(TObject *Sender)
{
ScrollBar6->Position = 97;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::SpeedButton8Click(TObject *Sender)
{
ScrollBar6->Position =30;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::SpeedButton10Click(TObject *Sender)
{
ScrollBar6->Position = 82;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::SpeedButton11Click(TObject *Sender)
{
ScrollBar6->Position = 17;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::SpeedButton13Click(TObject *Sender)
{
ScrollBar6->Position = 74;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::SpeedButton14Click(TObject *Sender)
{
ScrollBar6->Position = 7;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::SpeedButton3Click(TObject *Sender)
{
ScrollBar5->Position = 100;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::SpeedButton6Click(TObject *Sender)
{
ScrollBar5->Position = 230;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::SpeedButton9Click(TObject *Sender)
{
ScrollBar5->Position = 215;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::SpeedButton12Click(TObject *Sender)
{
ScrollBar5->Position = 245;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::SpeedButton15Click(TObject *Sender)
{
ScrollBar5->Position = 185;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::TrackBar1Change(TObject *Sender)
{
ScrollBar3->Position=255-TrackBar1->Position;
}
//---------------------------------------------------------------------------


void __fastcall TForm2::TrackBar2Change(TObject *Sender)
{
ScrollBar5->Position=255-TrackBar2->Position;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::TrackBar3Change(TObject *Sender)
{
ScrollBar6->Position=255-TrackBar3->Position;
}
//---------------------------------------------------------------------------


void __fastcall TForm2::ScrollBar4Change(TObject *Sender)
{
Label8->Caption=255-ScrollBar4->Position;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::ScrollBar7Change(TObject *Sender)
{
Label11->Caption=255-ScrollBar7->Position;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::ScrollBar8Change(TObject *Sender)
{
Label12->Caption=255-ScrollBar8->Position;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::ScrollBar9Change(TObject *Sender)
{
 Label13->Caption=255-ScrollBar9->Position;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::ScrollBar10Change(TObject *Sender)
{
  Label14->Caption=255-ScrollBar10->Position;
}
//---------------------------------------------------------------------------

