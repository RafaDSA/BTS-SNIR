var mdp1 = document.getElementById("mdp1");
var mdp2 = document.getElementById("mdp2");
var button_inscr = document.getElementById("bouton_inscription");
button_inscr.addEventListener('click',VerifierFormulaireInscr);
function VerifierFormulaireInscr(event) {
    if(mdp1.value!=mdp2.value){
        alert("Les mot de passes sont différents")
        event.preventDefault()
    }
}

var verifmdp = document.getElementById("mdp1");
verifmdp.addEventListener('input',Verifiermdp);
function Verifiermdp(){
    /*--------------*/
    var Nbmaj=0;
    var Nbmin=0;
    /*--------------*/
    if (verifmdp.value.length>=8){
        if(document.getElementById("mdp_longueur").classList.contains('rouge'))
        {
            document.getElementById("mdp_longueur").classList.remove('rouge');
            document.getElementById("mdp_longueur").classList.add('vert');
        }
    }
    else{
        document.getElementById("mdp_longueur").classList.remove('vert');
        document.getElementById("mdp_longueur").classList.add('rouge');
    }

    /*--------------*/
    for (var i = 0; i < verifmdp.value.length; i++ ){
        if (verifmdp.value.charAt(i)>='A' && verifmdp.value.charAt(i)<='Z'){
            Nbmaj++;
        }
    }
    if(Nbmaj>=1){
        if(document.getElementById("mdp_majuscule").classList.contains('rouge'))
        {
            document.getElementById("mdp_majuscule").classList.remove('rouge');
            document.getElementById("mdp_majuscule").classList.add('vert');
        }
    }else
    {
        document.getElementById("mdp_majuscule").classList.remove('vert');
        document.getElementById("mdp_majuscule").classList.add('rouge');
    }
    /*--------------*/
    if(Nbmin>=1){
        if(document.getElementById("mdp_minuscule").classList.contains('rouge'))
        {
            document.getElementById("mdp_minuscule").classList.remove('rouge');
            document.getElementById("mdp_minuscule").classList.add('vert');
        }
    }else
    {
        document.getElementById("mdp_minuscule").classList.remove('vert');
        document.getElementById("mdp_minuscule").classList.add('rouge');
    }
    
}


var verifnom = document.getElementById("nom");
var button_inscri = document.getElementById("bouton_inscription");
button_inscri.addEventListener('input',Verifiernom);
function Verifiernom(event){
    if(verifnom.value<3 && verifnom.value>15){
            alert("Le nom ne possède le nombre de caracteres requis")
            event.preventDefault()
        }
}